import React, { useState } from "react";
import "./App.css";

function App() {

  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const API_KEY = "9506cb140e4ca2afaec61c9d8b50da4c";

  const searchWeather = async () => {

    if (city.trim() === "") {
      setError("Please enter a city name");
      setWeather(null);
      return;
    }

    setLoading(true);
    setError("");
    setWeather(null);

    try {

      const url =
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error("City not found");
      }

      const data = await response.json();

      setWeather(data);

    } catch (err) {

      setError(err.message);

    } finally {

      setLoading(false);

    }
  };

  const getTime = (timestamp, timezone) => {

    const date = new Date((timestamp + timezone) * 1000);

    return date.toUTCString().slice(17, 22);
  };

  return (
    <div className="container">

      <h1>🌤 Weather Dashboard</h1>

      <div className="search-box">

        <input
          type="text"
          placeholder="Enter city name"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              searchWeather();
            }
          }}
        />

        <button onClick={searchWeather}>
          Search
        </button>

      </div>

      {loading && (
        <div className="spinner">
          <div></div>
          <p>Loading weather...</p>
        </div>
      )}

      {error && (
        <div className="error">
          ❌ {error}
        </div>
      )}

      {weather && !loading && (

        <div className="weather-card">

          <h2>
            {weather.name}, {weather.sys.country}
          </h2>

          <img
            src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
            alt="Weather Icon"
          />

          <h3>
            {Math.round(weather.main.temp)}°C
          </h3>

          <p className="description">
            {weather.weather[0].description}
          </p>

          <div className="weather-info">

            <div className="info-box">
              <span>🌡</span>
              <b>Temperature</b>
              <p>{Math.round(weather.main.temp)}°C</p>
            </div>

            <div className="info-box">
              <span>💧</span>
              <b>Humidity</b>
              <p>{weather.main.humidity}%</p>
            </div>

            <div className="info-box">
              <span>💨</span>
              <b>Wind Speed</b>
              <p>{weather.wind.speed} m/s</p>
            </div>

            <div className="info-box">
              <span>🌅</span>
              <b>Sunrise</b>
              <p>
                {getTime(
                  weather.sys.sunrise,
                  weather.timezone
                )}
              </p>
            </div>

            <div className="info-box">
              <span>🌇</span>
              <b>Sunset</b>
              <p>
                {getTime(
                  weather.sys.sunset,
                  weather.timezone
                )}
              </p>
            </div>

          </div>

        </div>

      )}

    </div>
  );
}

export default App;